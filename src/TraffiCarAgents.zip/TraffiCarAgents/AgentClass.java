package TrafficarClasses;

import jade.core.*;
import jade.core.behaviours.*;

public class AgentClass
{
	public AID aid;
	public String name;
	public String type;
	public double x;
	public double y;
	public String direction;
	public String lightColor;
}